const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const data = JSON.parse(read('content.json'));
const {matches} = require('../dist/logic.js');

test('independent project participates in category, role, and technical CV searches', () => {
  const projects = data.entries.filter(e => e.title === 'The Daily Gathering');
  assert.equal(projects.length, 1);
  const entry = projects[0];
  for (const query of ['Daily Gathering', 'lead developer', 'platform architect', 'AI', 'Gemini', 'React', 'TypeScript', 'systems integration']) {
    assert.equal(matches(entry, 'All', query), true, query);
  }
  assert.equal(matches(entry, 'Digital projects', ''), true);
  assert.equal(matches(entry, 'Scholarship', ''), false);
  assert.equal(matches(entry, 'Experience', ''), false);
  assert.equal(matches(entry, 'All', 'unrelated-term'), false);
});

test('project is first in Selected Work, has a working dialog target, and appears in print', () => {
  const home = read('dist/index.html');
  assert.ok(home.indexOf('id="work"') < home.indexOf('id="daily-gathering"'));
  assert.ok(home.indexOf('id="daily-gathering"') < home.indexOf('class="adams-art"'));
  assert.match(home, /data-open="daily-gathering-dialog"/);
  assert.match(home, /<dialog id="daily-gathering-dialog"[^>]*aria-labelledby="dg-case-title"/);
  assert.match(home, /data-category="Digital projects"/);
  const print = read('dist/cv.html');
  assert.match(print, /Selected Digital Projects and Technical Innovation/);
  assert.match(print, /The Daily Gathering/);
  assert.match(print, /href="https:\/\/dailygathr\.org\/"/);
  assert.match(print, /Relevant expertise: Full-stack development/);
});

test('published project assets and rollout qualifications survive the build', () => {
  const home = read('dist/index.html');
  for (const file of ['daily-gathering-home.webp', 'daily-gathering-home-720.webp', 'daily-gathering-bible.webp', 'daily-gathering-study.webp']) {
    assert.ok(fs.statSync(path.join(root, 'dist/assets', file)).size > 0, file);
    assert.ok(home.includes(file), file);
  }
  assert.match(home, /newsletter signup is marked <strong>coming soon<\/strong>/);
  assert.match(home, /questions are <strong>temporarily unavailable<\/strong>/);
  assert.match(home, /Independent &amp; noncommercial/);
  assert.match(home, /adams-photo-upright/);
  assert.match(home, /chriswecox@outlook\.com/);
  assert.match(home, /Chris\.Cox@wcmo\.edu/);
  assert.match(home, /\$900\+/);
  for (const name of ['dist/index.html', 'dist/cv.html', 'dist/card/index.html']) {
    assert.doesNotMatch(read(name), /[\u0080-\u009f\ufffd]|\u00e2\u0086|\u00c2\u00b7/);
  }
});
