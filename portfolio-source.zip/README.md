# Chris Cox — interactive CV and portfolio

A responsive HTML/CSS/JavaScript portfolio with a small Python/Node build step. The deployable assets are in `dist/`. No backend, npm installation, or API keys are required.

## Deploy to GitHub Pages

See [START_HERE.md](START_HERE.md) for upload and setup instructions. The included `.github/workflows/deploy-pages.yml` builds, validates, and deploys on each push to `main`. Choose **GitHub Actions** as the Pages source in repository settings, then run the workflow.

The workflow uses GitHub's actual Pages URL, including a repository subpath or configured custom domain. No username or hostname replacement is needed. Only `dist/` is uploaded as the website. The full source remains in the repository and in the site's source ZIP.

## Edit

- `content.json` is the source of truth for the CV and teaching explorer.
- `templates/index.html` is the main page template.
- `dist/styles.css`, `dist/app.js`, and `dist/logic.js` contain the design and interactions.
- `templates/business-card.html` is shared by the contact dialog and `/card/` page. `dist/card.css`, `dist/card.js`, and `dist/card-core.js` provide the card design and behavior.
- `content.json` also stores professional contact details under `contact`. `contact.siteUrl` is the local preview default; `SITE_URL` overrides it during deployment. Interactive sharing, QR generation, and contact downloads follow the current browser URL automatically, including GitHub repository subpaths.
- Run `python generate.py` after changing content or templates. This updates the CV views, contact assets, sharing metadata, and downloadable source bundle.
- Open through a static HTTP server when running the project outside Sites. No package installation, API keys, or backend are required.

## Local preview

Use Python 3.9 or newer and Node.js 18 or newer; the deployment workflow selects Python 3.13 and Node.js 24. From the repository folder:

```sh
python generate.py
python -m http.server 8000 --directory dist
```

Open `http://localhost:8000/` and `http://localhost:8000/card/`. Stop the server with Ctrl+C. On systems where the command is named `python3`, use that instead. The checked-in preview address is `http://localhost:8000/`. Static contact files and QR codes from a local preview are for local use; use the deployed site's downloads for sharing.

For a build outside GitHub Pages, supply your site's full base URL including any repository path:

```sh
# macOS / Linux
SITE_URL="https://example.github.io/portfolio/" python3 generate.py
```

```powershell
# Windows PowerShell
$env:SITE_URL = "https://example.github.io/portfolio/"
python generate.py
```

An HTTP(S) site root is required; a trailing slash is normalized automatically. Query strings, fragments, and embedded credentials are rejected. In GitHub Actions, an absent URL stops the build so a preview address cannot be published silently.

## Working features

The live design workbench adjusts CSS variables and compact layout. Insertion sort generates real comparison and swap states with play/pause, stepping, replay, reset, speed, and shuffle. The course explorer filters teaching areas. The CV supports multi-word keyword search, category filters, progressive disclosure, and a full print view. The theme is remembered locally. Native dialogs, semantic controls, focus styles, and reduced-motion CSS are included. The business card provides email/call links, a vCard contact download, native sharing where available, copy-link/manual-copy fallback, and a QR code with an SVG download. It can be opened in a dialog or visited directly at `/card/`. Shared links require a publicly accessible deployment; contact-file downloads do not change site access.

This site does not contain analytics, contact submissions, AI API calls, or third-party scripts. The email link opens the visitor's email application. Changing a demo affects only the current page; the color theme is saved in the visitor's browser.

## Content provenance and scope

- Primary CV: `Cox CV 2026.docx`, September 18, 2026 version supplied by Chris.
- Doctoral admission: Dakota State University acceptance letter for Spring 2027, supplied October 13, 2026. Listed as admission, not enrollment or candidacy. No private letter or home address is included.
- DC Comics fandom: Chris's confirmed accepted proposal for an encyclopedia contribution to *Pop Culture Fandoms*, edited by Paul Booth, Bloomsbury. The manuscript remains in preparation; no publication date or published chapter is claimed.
- Faculty profile: https://www.wcmo.edu/fac-staff/chris-cox.html
- Client project: https://www.adamsk9llc.com/ — launched per Chris's October 2026 account. Project notes describe the supplied project history. No performance metrics are asserted.
- Adams K9 photograph: existing client-site asset at https://static.wixstatic.com/media/04c67f_dcd77d9471c145848984b2617c637120~mv2.jpg, optimized for this portfolio. The project tile is a portfolio composition using the client's image, not a screenshot. Photograph remains its owner's property.
- Course focus lines are brief editorial descriptions of subjects, not official catalog descriptions.
- Portrait, campus headshot, and classroom photo: supplied by Chris on October 13, 2026. Optimized as WebP without generative alterations; original files remain unchanged. Close portrait framing is done in CSS. Classroom branding remains visible.
- QR encoder: locally bundled `qrcode-generator` 1.4.4 by Kazuhiko Arase, MIT license. No third-party QR service receives contact information.
- Teaching evaluation score is the response-weighted mean on the IDEA excellent-teacher item across available Fall 2021–Spring 2026 reports; advising counts are dated Fall 2026.

Preserve status labels when updating scholarship, proposals, and education. No confidential manuscripts, admissions letters, or institutional documents are bundled.

## Validation

Run `node --test tests/logic.test.cjs tests/card.test.cjs`, `python tests/deployment_test.py`, and `python validate.py` after generating. The deployment tests verify account-site, repository-site, and custom-domain URLs, downloadable contact details, and the complete source archive. The static checks cover links, controls, images, CV counts, and status wording. A fresh live browser check is still needed after GitHub publishes your site.
