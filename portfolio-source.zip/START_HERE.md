# Put Chris's portfolio on GitHub Pages

This kit includes the complete portfolio, all three photos, the interactive CV,
the accepted DC Comics proposal feature, and the shareable business card.
You do not need to rebuild the site in a page editor or install anything to deploy it.

## One-time setup

1. **Extract this ZIP.** Open the `Chris_Cox_GitHub_Pages` folder.
2. **Create a repository at https://github.com/new.** Name it `portfolio`, select
   **Public** for GitHub's free Pages hosting, and initialize it with a README.
   The default branch should be `main`.
3. In the repository, choose **Add file → Upload files**. Upload the **contents**
   of the extracted folder, including the folders `dist`, `templates`, `tests`,
   and `.github`. Commit to `main`. `content.json` and `generate.py` should be
   visible at the top level of your repository. Do not upload the ZIP itself
   or put everything inside another parent folder.
4. Open **Settings → Pages**. Under **Build and deployment**, set **Source**
   to **GitHub Actions**. You do not need a Jekyll or other starter workflow;
   this kit already contains its workflow.
5. Open **Actions → Deploy portfolio to GitHub Pages → Run workflow**. Select
   `main` and run it. Once both the build and deploy jobs are green, open the
   site link shown by the deployment or in **Settings → Pages**.

The upload may start a run before you enable Pages. If that first run fails at
“Read the GitHub Pages address,” complete step 4 and run the workflow again.

### If `.github` does not appear after uploading

Some file pickers hide folders whose names start with a dot. A computer is the
easiest way to upload the complete folder tree. If `.github` was omitted:

1. In GitHub choose **Add file → Create new file**.
2. Name the new file **`.github/workflows/deploy-pages.yml`**. Include the full path.
3. Open `DEPLOY_WORKFLOW.txt` from this kit, copy all of its contents into the
   new file, and commit to `main`.
4. Continue with the Pages setting and Run workflow steps above.

`DEPLOY_WORKFLOW.txt` is a convenience copy for initial installation. GitHub only
runs `.github/workflows/deploy-pages.yml`; edit that file for later workflow changes.

## Your addresses

For a repository named `portfolio`, your website will normally be:

- Portfolio: `https://YOUR-USERNAME.github.io/portfolio/`
- Business card: `https://YOUR-USERNAME.github.io/portfolio/card/`

Replace `YOUR-USERNAME` with your GitHub account name. These examples are not
settings you need to edit: the workflow gets your real URL directly from GitHub
and builds the sharing metadata, downloadable contact file, and QR code with it.
The kit's prebuilt `dist` files use a local preview address until that first build.

Visitors can open your business card, save your contact, copy its link, download
its QR code, or use their device's Share menu to text it. Available share targets
depend on the visitor's browser and installed apps.

## Updating the site

Edit and commit to `main`; the workflow rebuilds and publishes automatically.

- CV entries, teaching courses, and contact data: `content.json`.
- Main page: `templates/index.html`.
- Business card text/layout: `templates/business-card.html`.
- Styling and interactions: the CSS and JavaScript files in `dist`.

Do not edit generated `dist/index.html`, `dist/card/index.html`, `dist/cv.html`,
or `dist/data.js` to change content; the next build replaces them.
No personal access token, paid API, database, or npm installation is required.

## If something goes wrong

- **No workflow listed:** check that `.github/workflows/deploy-pages.yml` exists
  on `main` and Actions are enabled for the repository.
- **Pages setup failure:** set Settings → Pages → Source to GitHub Actions, then
  run the workflow again.
- **Site shows a README or a 404:** check the upload is at the repository root,
  the Source is GitHub Actions, and the deploy job finished successfully.
- **A link or QR seems out of date:** open your actual GitHub Pages site and let
  the newest deployment finish; your local ZIP is a preview, not the hosted copy.
- **Using a different branch:** change `branches: [main]` in the workflow and
  ensure the `github-pages` environment allows that branch.

If you later connect a custom domain, configure it in Settings → Pages and run
the workflow again. The new build uses GitHub's configured address automatically.

This kit has been built and checked locally. A deployment has not been made to
your GitHub account, and a live browser check of that deployment remains to be done.

Official reference: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
